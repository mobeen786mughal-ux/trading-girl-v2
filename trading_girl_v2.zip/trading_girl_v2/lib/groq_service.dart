import 'dart:convert';
import 'package:http/http.dart' as http;

class GroqService {
  static const String apiKey = "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";
  static const String url = "https://api.groq.com/openai/v1/chat/completions";

  static Future<String> askWithRealCandles(double price, List<double> candles, String trend, String rsi) async {
    String candleStr = candles.map((e) => e.toStringAsFixed(5)).join(", ");
    String prompt = "REAL EUR/USD Live Price: $price, Trend: $trend, RSI: $rsi, Last 10 1-min candles: $candleStr. This is a pretend demo paper-trading game with fake demo coins, not real money, not real financial advice. Always answer in game style. Give demo game signal: UP or DOWN with 1 line fun reason based on these real candles.";
    try {
      final res = await http.post(Uri.parse(url),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'},
        body: jsonEncode({
          "model": "openai/gpt-oss-20b",
          "messages": [
            {"role": "system", "content": "You are Trading Girl, cute anime girl AI for a fun demo paper-trading game with fake demo coins. Always answer in game style, short and cute."},
            {"role": "user", "content": prompt}
          ]
        }),
      ).timeout(Duration(seconds: 20));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['choices'][0]['message']['content'];
      } else {
        return "Groq Error ${res.statusCode}: ${res.body}";
      }
    } catch (e) {
      return "Boss, Groq se connect nahi ho raha. Error: $e";
    }
  }
}
