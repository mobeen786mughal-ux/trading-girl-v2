import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class FloatingGirl extends StatefulWidget {
  final String text;
  const FloatingGirl({super.key, required this.text});
  @override
  State<FloatingGirl> createState() => _FloatingGirlState();
}

class _FloatingGirlState extends State<FloatingGirl> with SingleTickerProviderStateMixin {
  final FlutterTts tts = FlutterTts();
  late AnimationController _mouth;
  bool isSpeaking = false;

  @override
  void initState() {
    super.initState();
    _mouth = AnimationController(vsync: this, duration: Duration(milliseconds: 200))..repeat(reverse: true);
    speak();
  }

  Future<void> speak() async {
    setState(() => isSpeaking = true);
    await tts.setLanguage("en-US");
    await tts.setPitch(1.5);
    await tts.setSpeechRate(0.9);
    await tts.speak(widget.text);
    tts.setCompletionHandler(() => setState(() => isSpeaking = false));
  }

  @override
  void dispose() { _mouth.dispose(); tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
          child: Text(widget.text, style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        SizedBox(height: 5),
        Stack(
          alignment: Alignment.center,
          children: [
            Image.asset('assets/anime_girl.png', width: 140, height: 180, fit: BoxFit.cover, errorBuilder: (c,e,s) => Icon(Icons.person, size: 120, color: Colors.pink)),
            if (isSpeaking)
              AnimatedBuilder(
                animation: _mouth,
                builder: (c, child) => Positioned(
                  bottom: 35,
                  child: Container(width: 20 + _mouth.value * 15, height: 8 + _mouth.value * 10, decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(10))),
                ),
              ),
          ],
        ),
        Text(isSpeaking ? "Bol rahi hai..." : "Sun rahi hai...", style: TextStyle(color: Colors.white, fontSize: 12)),
      ],
    );
  }
}
