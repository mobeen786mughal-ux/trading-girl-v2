import 'dart:convert';
import 'package:http/http.dart' as http;

class ForexService {
  static Future<Map<String, dynamic>> getRealCandles() async {
    try {
      final res = await http.get(Uri.parse('https://query1.finance.yahoo.com/v8/finance/chart/EURUSD=X?interval=1m&range=1d')).timeout(Duration(seconds: 15));
      final data = jsonDecode(res.body);
      final result = data['chart']['result'][0];
      final closes = List<double>.from((result['indicators']['quote'][0]['close'] as List).where((e) => e != null).map((e) => (e as num).toDouble()));
      final last10 = closes.length > 10 ? closes.sublist(closes.length - 10) : closes;
      double price = last10.last;
      double first = last10.first;
      String trend = price > first ? "UP TREND" : price < first ? "DOWN TREND" : "SIDEWAYS";
      double gains = 0, losses = 0;
      for (int i = 1; i < last10.length; i++) {
        double diff = last10[i] - last10[i-1];
        if (diff > 0) gains += diff; else losses += -diff;
      }
      double rs = losses == 0 ? 100 : gains / losses;
      double rsi = 100 - (100 / (1 + rs));
      return {'price': price, 'candles': last10, 'trend': trend, 'rsi': rsi.toStringAsFixed(1), 'ok': true};
    } catch (e) {
      return {'ok': false, 'error': e.toString()};
    }
  }
}
