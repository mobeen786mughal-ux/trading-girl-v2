import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:system_alert_window/system_alert_window.dart';
import 'forex_service.dart';
import 'groq_service.dart';
import 'floating_girl.dart';

void main() => runApp(TradingGirlApp());

class TradingGirlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: HomePage());
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = "Girl ready hai! Analyze dabao";
  String signal = "";
  double price = 0;
  String trend = "";
  String rsi = "";
  bool loading = false;
  bool showGirl = false;
  bool floatingOn = false;
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _initTts();
    SystemAlertWindow.registerOnClickListener((tag) {
      if (tag == "close_btn") {
        closeFloating();
      }
    });
  }

  // DHEERE WALI AWAZ - 0.32
  Future<void> _initTts() async {
    await tts.setLanguage("en-IN");
    await tts.setSpeechRate(0.32);
    await tts.setVolume(1.0);
    await tts.setPitch(1.0);
  }

  Future<void> speak(String text) async {
    try {
      await tts.stop();
      await tts.setLanguage("en-IN");
      await tts.setSpeechRate(0.32);
      // Har sentence ke baad rukegi - Tez nahi lagegi
      String slowText = text.replaceAll(". ", "... ").replaceAll("! ", "... ").replaceAll(", ", ", ... ");
      await tts.speak(slowText);
      setState(() { status = "Bol rahi hai... 🔊 Dheere dheere"; });
    } catch (e) {
      setState(() { status = "Bolne me masla: $e"; });
    }
  }

  Future<void> analyzeReal() async {
    setState(() { loading = true; status = "REAL Candle le rahi hun..."; showGirl = false; });
    final forex = await ForexService.getRealCandles();
    if (forex['ok'] != true) {
      setState(() { status = "Price nahi mila: ${forex['error']}"; loading = false; });
      return;
    }
    price = forex['price'];
    trend = forex['trend'];
    rsi = forex['rsi'];
    setState(() { status = "REAL Price: $price | Trend: $trend | RSI: $rsi\nAI soch rahi hai..."; });
    String ans = await GroqService.askWithRealCandles(price, List<double>.from(forex['candles']), trend, rsi);
    setState(() { signal = ans; status = "REAL Candle se jawab aa gaya!"; loading = false; showGirl = true; });
    speak(ans);
    if (floatingOn) { showFloating(); }
  }

  // FLOATING - system_alert_window wala - itel pe chalne wala
  Future<void> showFloating() async {
    bool granted = await SystemAlertWindow.checkPermissions() ?? false;
    if (!granted) {
      await SystemAlertWindow.requestPermissions();
      setState(() { status = "Floating Permission Allow karo - Phir dobara dabao"; });
      return;
    }
    String sig = signal.isEmpty ? "Girl ready hai!" : signal;
    if (sig.length > 80) sig = sig.substring(0, 80) + "...";
    await SystemAlertWindow.showSystemWindow(
      height: 220,
      width: 180,
      gravity: SystemWindowGravity.TOP_RIGHT,
      header: SystemWindowHeader(
        title: SystemWindowText(text: "👧 Trading Girl", fontSize: 14, textColor: Colors.pink),
        padding: SystemWindowPadding(left: 8, right: 8, top: 8, bottom: 0),
        decoration: SystemWindowDecoration(startColor: Colors.pink[100]),
      ),
      body: SystemWindowBody(
        rows: [
          EachRow(
            columns: [
              EachColumn(
                text: SystemWindowText(text: sig, fontSize: 11, textColor: Colors.black),
              ),
            ],
          ),
          EachRow(
            columns: [
              EachColumn(
                text: SystemWindowText(text: "Price: $price", fontSize: 11, fontWeight: FontWeight.bold, textColor: Colors.green),
              ),
            ],
          ),
        ],
        padding: SystemWindowPadding(left: 8, right: 8, top: 4, bottom: 4),
        decoration: SystemWindowDecoration(startColor: Colors.white),
      ),
      footer: SystemWindowFooter(
        buttons: [
          SystemWindowButton(
            text: SystemWindowText(text: "❌ Band", fontSize: 12, textColor: Colors.white),
            tag: "close_btn",
            decoration: SystemWindowDecoration(startColor: Colors.pink, endColor: Colors.pink),
            padding: SystemWindowPadding(left: 10, right: 10, top: 4, bottom: 4),
          ),
        ],
        padding: SystemWindowPadding(left: 8, right: 8, top: 4, bottom: 8),
        decoration: SystemWindowDecoration(startColor: Colors.white),
      ),
      margin: SystemWindowMargin(left: 8, right: 8, top: 100, bottom: 0),
    );
    setState(() { floatingOn = true; status = "Floating ON - Ab Quotex kholo, Girl upar tairegi!"; });
  }

  Future<void> closeFloating() async {
    await SystemAlertWindow.closeSystemWindow();
    setState(() { floatingOn = false; status = "Floating Band ho gayi"; });
  }

  Future<void> toggleFloating() async {
    if (floatingOn) {
      await closeFloating();
    } else {
      await showFloating();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(title: Text("Trading Girl V2 - REAL"), backgroundColor: Colors.pink),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            if (price != 0) Card(child: ListTile(title: Text("REAL EUR/USD: $price"), subtitle: Text("Trend: $trend | RSI: $rsi"))),
            SizedBox(height: 10),
            Text(status, textAlign: TextAlign.center),
            SizedBox(height: 10),
            if (showGirl) Container(height: 380, child: FloatingGirl(text: signal)),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: loading ? null : analyzeReal,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, minimumSize: Size(double.infinity, 55)),
              child: Text(loading ? "Analyzing REAL Candle..." : "🔍 REAL Analyze Karo", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: toggleFloating,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple, minimumSize: Size(double.infinity, 55)),
              child: Text(floatingOn ? "❌ Floating Band Karo" : "👧 Floating Girl ON / OFF", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => speak("Hello, I am Trading Girl. Market is ready. Game on!"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, minimumSize: Size(double.infinity, 50)),
              child: Text("🔊 Awaz Test Karo - Dheere Wali", style: TextStyle(fontSize: 16, color: Colors.white)),
            ),
            SizedBox(height: 12),
            Text("Floating: Pehle Floating Button dabao, Permission Allow karo, phir Quotex kholo!", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}