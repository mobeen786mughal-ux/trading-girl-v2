import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'forex_service.dart';
import 'groq_service.dart';
import 'floating_girl.dart';

void main() => runApp(TradingGirlApp());

class TradingGirlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: HomePage());
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = "Girl ready hai! Analyze dabao";
  String signal = "";
  double price = 0;
  String trend = "";
  String rsi = "";
  bool loading = false;
  bool showGirl = false;
  bool floatingOn = false;
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _initTts();
  }

  Future<void> _initTts() async {
    await tts.setLanguage("en-IN");
    await tts.setSpeechRate(0.5);
    await tts.setVolume(1.0);
    await tts.setPitch(1.1);
  }

  Future<void> speak(String text) async {
    try {
      await tts.stop();
      await tts.setLanguage("en-IN");
      await tts.speak(text);
      setState(() { status = "Bol rahi hai... 🔊"; });
    } catch (e) {
      setState(() { status = "Bolne me masla: $e"; });
    }
  }

  Future<void> analyzeReal() async {
    setState(() { loading = true; status = "REAL Candle le rahi hun..."; showGirl = false; });
    final forex = await ForexService.getRealCandles();
    if (forex['ok'] != true) { setState(() { status = "Price nahi mila: ${forex['error']}"; loading = false; }); return; }
    price = forex['price']; trend = forex['trend']; rsi = forex['rsi'];
    setState(() { status = "REAL Price: $price | Trend: $trend | RSI: $rsi\nAI soch rahi hai..."; });
    String ans = await GroqService.askWithRealCandles(price, List<double>.from(forex['candles']), trend, rsi);
    setState(() { signal = ans; status = "REAL Candle se jawab aa gaya!"; loading = false; showGirl = true; });
    speak(ans);
  }

  Future<void> toggleFloating() async {
    bool granted = await FlutterOverlayWindow.isPermissionGranted();
    if (!granted) {
      await FlutterOverlayWindow.requestPermission();
      setState(() { status = "Floating Permission ON karo - Settings > Draw Over Apps > Allow"; });
      return;
    }
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
      setState(() { floatingOn = false; status = "Floating Band ho gayi"; });
    } else {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: "Trading Girl",
        overlayContent: signal.isEmpty ? "Girl ready hai!" : signal,
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        height: 250,
        width: 200,
      );
      setState(() { floatingOn = true; status = "Floating ON - Ab Quotex kholo, Girl upar tairegi!"; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(title: Text("Trading Girl V2 - REAL"), backgroundColor: Colors.pink),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            if (price != 0) Card(child: ListTile(title: Text("REAL EUR/USD: $price"), subtitle: Text("Trend: $trend | RSI: $rsi"))),
            SizedBox(height: 10),
            Text(status, textAlign: TextAlign.center),
            SizedBox(height: 10),
            if (showGirl) Container(height: 380, child: FloatingGirl(text: signal)),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: loading ? null : analyzeReal,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, minimumSize: Size(double.infinity, 55)),
              child: Text(loading ? "Analyzing REAL Candle..." : "🔍 REAL Analyze Karo", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: toggleFloating,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple, minimumSize: Size(double.infinity, 55)),
              child: Text(floatingOn ? "❌ Floating Band Karo" : "👧 Floating Girl ON / OFF", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => speak("Hello, I am Trading Girl. Market is ready. Game on!"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, minimumSize: Size(double.infinity, 50)),
              child: Text("🔊 Awaz Test Karo", style: TextStyle(fontSize: 16, color: Colors.white)),
            ),
            SizedBox(height: 12),
            Text("Floating: Pehle Floating Button dabao, Permission Allow karo, phir Quotex kholo - Girl upar tairegi!", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}