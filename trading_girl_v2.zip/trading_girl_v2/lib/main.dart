import 'package:flutter/material.dart';
import 'forex_service.dart';
import 'groq_service.dart';
import 'floating_girl.dart';

void main() => runApp(TradingGirlApp());

class TradingGirlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: HomePage());
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = "Girl ready hai! Analyze dabao";
  String signal = "";
  double price = 0;
  String trend = "";
  String rsi = "";
  bool loading = false;
  bool showGirl = false;

  Future<void> analyzeReal() async {
    setState(() { loading = true; status = "REAL Candle le rahi hun..."; showGirl = false; });
    final forex = await ForexService.getRealCandles();
    if (forex['ok'] != true) { setState(() { status = "Price nahi mila: ${forex['error']}"; loading = false; }); return; }
    price = forex['price']; trend = forex['trend']; rsi = forex['rsi'];
    setState(() { status = "REAL Price: $price | Trend: $trend | RSI: $rsi\nAI soch rahi hai..."; });
    String ans = await GroqService.askWithRealCandles(price, List<double>.from(forex['candles']), trend, rsi);
    setState(() { signal = ans; status = "REAL Candle se jawab aa gaya!"; loading = false; showGirl = true; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(title: Text("Trading Girl V2 - REAL"), backgroundColor: Colors.pink),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            if (price != 0) Card(child: ListTile(title: Text("REAL EUR/USD: $price"), subtitle: Text("Trend: $trend | RSI: $rsi"))),
            SizedBox(height: 10),
            Text(status, textAlign: TextAlign.center),
            SizedBox(height: 10),
            if (showGirl) Expanded(child: FloatingGirl(text: signal)),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: loading ? null : analyzeReal,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, minimumSize: Size(double.infinity, 55)),
              child: Text(loading ? "Analyzing REAL Candle..." : "🔍 REAL Analyze Karo", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
            SizedBox(height: 8),
            Text("Floating: Settings > Draw Over Other Apps > ON kar do, phir Girl Quotex ke upar bhi tairेगी", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
